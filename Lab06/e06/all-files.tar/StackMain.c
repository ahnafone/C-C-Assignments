#include "Stack.h"
#include <cstdio>
#include <cassert>

int main()
{
  // test all Stack functions
  // including assert violations
  // (guarded by #if 0 / #endif)

  // ...

  return 0;
}
