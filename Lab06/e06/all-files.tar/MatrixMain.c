#include "Matrix.h"
#include <cstdio>
#include <cassert>

int main()
{

  // test code for all functions
  // including failing pre-conditions
  // (guarded by #if 0 ... #endif)
  
  // ...

  return 0;
}
